import { Component, OnInit } from '@angular/core';
import { AuthService } from '../auth.service';
import { Router } from '@angular/router';
import { User } from '../model/user';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  username: String;
  password: String;
  user: User[];
  constructor(private router: Router, private authService: AuthService) { }

  ngOnInit() {
    this.authService.getAllUsers().subscribe(response => this.handleResponse(response));
  }

  handleResponse(response) {
    this.user = response;
  }
  checkLogin() {
    console.log("triggered")
    for (let i = 0; i < this.user.length; i++) {
      if (this.user[i].name === this.username && this.user[i].password === this.password) {
        this.router.navigate(['welcome']);
        localStorage.setItem("userId", this.user[i].id.toString());
      } else {
        this.router.navigate(['']);
      }
    }
  }

  onSubmit() {
    this.checkLogin();
  }

}




