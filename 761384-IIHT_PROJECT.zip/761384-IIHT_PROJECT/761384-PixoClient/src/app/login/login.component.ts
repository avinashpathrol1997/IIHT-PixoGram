import { Component, OnInit } from '@angular/core';
import { AuthService } from '../auth.service';
import { User } from '../model/user';
import { NewsfeedComponent } from '../newsfeed/newsfeed.component';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  username: String="Avinash";
  password: String="root";
  email: String="a@gmail.com";
  constructor(private authService: AuthService) { }

  ngOnInit() {
  }

  loginUser(event) {
    console.log(event)
  }

  onSubmit() {
    console.log('In onSubmit');
    let user = new User(this.username, this.password, this.email);
    this.authService.registerNewUser(user).subscribe(response=>console.log(response));
  }

}
